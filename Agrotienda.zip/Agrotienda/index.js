require('dotenv').config();
const express = require('express');
const conectarDB = require('./config/db');
const productosRouter = require('./routes/productos.routes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use('/api/productos', productosRouter);

// JSON mal formado u otros errores: mensaje breve, sin trazas internas.
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ mensaje: 'JSON inválido' });
  }
  res.status(500).json({ mensaje: 'Error interno del servidor' });
});

conectarDB().then(() => {
  app.listen(PORT, () => console.log(`API escuchando en http://localhost:${PORT}`));
});