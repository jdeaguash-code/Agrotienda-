const mongoose = require('mongoose');

const productoSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, 'El nombre es obligatorio'],
      trim: true,
      minlength: [2, 'El nombre debe tener al menos 2 caracteres'],
    },
    categoria: {
      type: String,
      required: [true, 'La categoría es obligatoria'],
      trim: true,
    },
    precio: {
      type: Number,
      required: [true, 'El precio es obligatorio'],
      min: [0, 'El precio no puede ser negativo'],
    },
    existencias: {
      type: Number,
      required: [true, 'Las existencias son obligatorias'],
      min: [0, 'Las existencias no pueden ser negativas'],
      validate: {
        validator: Number.isInteger,
        message: 'Las existencias deben ser un número entero',
      },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Producto', productoSchema);