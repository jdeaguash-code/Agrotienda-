const mongoose = require('mongoose');
const Producto = require('../models/producto.model');

// Toma solo los campos permitidos del cuerpo de la petición.
function datos(body = {}) {
  const { nombre, categoria, precio, existencias } = body;
  return { nombre, categoria, precio, existencias };
}

// 400 si Mongoose rechaza los datos; 500 (mensaje genérico) para lo demás.
function manejarError(error, res) {
  if (error.name === 'ValidationError') {
    const mensaje = Object.values(error.errors).map((e) => e.message).join('; ');
    return res.status(400).json({ mensaje });
  }
  res.status(500).json({ mensaje: 'Error interno del servidor' });
}

const noEncontrado = (res) => res.status(404).json({ mensaje: 'Producto no encontrado' });

const listar = async (req, res) => {
  try {
    const productos = await Producto.find();
    res.status(200).json(productos);
  } catch (error) {
    manejarError(error, res);
  }
};

const obtenerPorId = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return noEncontrado(res);
    const producto = await Producto.findById(req.params.id);
    if (!producto) return noEncontrado(res);
    res.status(200).json(producto);
  } catch (error) {
    manejarError(error, res);
  }
};

const crear = async (req, res) => {
  try {
    const nuevo = await Producto.create(datos(req.body));
    res.status(201).json(nuevo);
  } catch (error) {
    manejarError(error, res);
  }
};

const actualizar = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return noEncontrado(res);
    const producto = await Producto.findById(req.params.id);
    if (!producto) return noEncontrado(res);
    producto.set(datos(req.body));
    await producto.save(); // valida el documento completo
    res.status(200).json(producto);
  } catch (error) {
    manejarError(error, res);
  }
};

const eliminar = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return noEncontrado(res);
    const producto = await Producto.findByIdAndDelete(req.params.id);
    if (!producto) return noEncontrado(res);
    res.status(204).send();
  } catch (error) {
    manejarError(error, res);
  }
};

module.exports = { listar, obtenerPorId, crear, actualizar, eliminar };